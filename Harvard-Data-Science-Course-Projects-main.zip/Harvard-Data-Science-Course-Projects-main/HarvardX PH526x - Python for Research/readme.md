<object data="https://github.com/azminewasi/Harvard-Data-Science-Course-Projects/blob/main/HarvardX%20PH526x%20-%20Python%20for%20Research/HarvardX%20PH526x%20Certificate%20_%20edX.pdf" type="application/pdf" width="700px" height="700px">
    <embed src="https://github.com/azminewasi/Harvard-Data-Science-Course-Projects/blob/main/HarvardX%20PH526x%20-%20Python%20for%20Research/HarvardX%20PH526x%20Certificate%20_%20edX.pdf">
        <p>This browser does not support PDFs. Please download the PDF to view it: <a href="https://github.com/azminewasi/Harvard-Data-Science-Course-Projects/blob/main/HarvardX%20PH526x%20-%20Python%20for%20Research/HarvardX%20PH526x%20Certificate%20_%20edX.pdf">Download PDF</a>.</p>
    </embed>
</object>
