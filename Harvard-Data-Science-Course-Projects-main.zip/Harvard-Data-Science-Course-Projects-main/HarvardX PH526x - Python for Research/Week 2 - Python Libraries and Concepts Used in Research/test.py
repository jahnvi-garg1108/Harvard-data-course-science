import pandas as pd
data = pd.Series([1,2,3,4])
data = data.ix[[3,0,1,2]]