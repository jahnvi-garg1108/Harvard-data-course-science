p + geom_density()
p + geom_density(fill = "blue")