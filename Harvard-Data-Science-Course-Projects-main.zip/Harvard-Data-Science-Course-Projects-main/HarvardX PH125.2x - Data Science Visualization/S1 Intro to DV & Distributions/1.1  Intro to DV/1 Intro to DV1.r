library(dslabs)
data(murders)
head(murders)
